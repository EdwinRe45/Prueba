
export enum Screen {
  Home = 'Inicio',
  Progress = 'Progreso',
  Challenge = 'Reto',
  Community = 'Comunidad',
  Create = 'Crear',
}
